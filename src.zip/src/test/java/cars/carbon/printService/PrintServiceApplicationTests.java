package cars.carbon.printService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrintServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
