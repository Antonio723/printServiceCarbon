package cars.carbon.printService.model.plate;

import cars.carbon.printService.enums.PlateStatus;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class PlateEvent {

    @Id
    @GeneratedValue
    private Long id;
    @SequenceGenerator(
            name = "plate_history_seq",
            sequenceName = "plate_history_sequence",
            allocationSize = 1
    )

    @ManyToOne
    private Plates plate;

    @Enumerated(EnumType.STRING)
    private PlateStatus type;

    private Double value; //Metragem consumida para operação de corte

    private String details; //"Usado para OS #1234", "Ciclo 88"

    private LocalDateTime timestamp; //Gravar o horario da alteração

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Plates getPlate() {
        return plate;
    }

    public void setPlate(Plates plate) {
        this.plate = plate;
    }

    public PlateStatus getType() {
        return type;
    }

    public void setType(PlateStatus type) {
        this.type = type;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}

