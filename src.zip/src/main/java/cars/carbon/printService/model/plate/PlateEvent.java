package cars.carbon.printService.model.plate;

import cars.carbon.printService.enums.PlateEventType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class PlateEvent {

    @Id
    @GeneratedValue
    private Long id;

    @ManyToOne
    private Plates plate;

    @Enumerated(EnumType.STRING)
    private PlateEventType eventType;

    private LocalDateTime eventDate;

    private Long referenceId;

    private Double consumedArea;

    private Double consumedLength;

    private String description;
}