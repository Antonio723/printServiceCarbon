package cars.carbon.printService.production.cutting.repository;

import cars.carbon.printService.production.cutting.model.CuttingProduction;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CuttingProductionRepository extends JpaRepository<CuttingProduction, Long> {
}