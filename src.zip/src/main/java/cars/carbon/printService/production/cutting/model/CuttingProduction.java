package cars.carbon.printService.production.cutting.model;

import cars.carbon.printService.production.cutting.enums.KitType;
import cars.carbon.printService.production.cutting.enums.MaterialType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
public class CuttingProduction {

    @Id
    @GeneratedValue
    private Long id;

    private String workOrder;

    @Enumerated(EnumType.STRING)
    private MaterialType material;

    @Enumerated(EnumType.STRING)
    private KitType kitType;

    private LocalDateTime productionDate;

    @OneToMany(mappedBy = "cuttingProduction", cascade = CascadeType.ALL)
    private List<CuttingLot> lots;

}
