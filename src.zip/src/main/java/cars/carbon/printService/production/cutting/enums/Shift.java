package cars.carbon.printService.production.cutting.enums;

public enum Shift {
    MORNING,
    AFTERNOON
}
