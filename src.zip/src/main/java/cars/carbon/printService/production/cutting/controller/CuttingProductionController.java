package cars.carbon.printService.production.cutting.controller;

import cars.carbon.printService.production.cutting.enums.LotType;
import cars.carbon.printService.production.cutting.enums.MaterialType;
import cars.carbon.printService.production.cutting.enums.Shift;
import cars.carbon.printService.production.cutting.model.CuttingProduction;
import cars.carbon.printService.production.cutting.service.CuttingProductionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cutting")
public class CuttingProductionController {

    private final CuttingProductionService service;

    public CuttingProductionController(CuttingProductionService service) {
        this.service = service;
    }

    /*@PostMapping
    public ResponseEntity<CuttingProduction> create(
            @RequestBody CuttingProduction cutting) {
        CuttingProduction result = service.registerCutting(cutting);
        return ResponseEntity.ok(result);
    }*/

    @GetMapping("/{id}")
    public ResponseEntity<CuttingProduction> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public CuttingProduction create(@RequestBody CuttingProduction production) {
        return service.create(production);
    }

    @GetMapping("/metadata")
    public Map<String,Object> metadata(){

        Map<String,Object> map = new HashMap<>();

        map.put("materials", MaterialType.values());
        map.put("lotTypes", LotType.values());
        map.put("shifts", Shift.values());

        return map;
    }
}