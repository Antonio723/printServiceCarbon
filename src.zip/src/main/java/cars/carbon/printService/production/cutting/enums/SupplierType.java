package cars.carbon.printService.production.cutting.enums;

public enum SupplierType {
    OPERA,
    COMTEC
}