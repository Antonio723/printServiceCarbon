package cars.carbon.printService.production.cutting.enums;

public enum KitType {
    KIT_COMUM,
    PECAS_AVULSAS,
    REBLINDAGEM,
    DESENVOLVIMENTO
}
