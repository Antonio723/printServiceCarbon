package cars.carbon.printService.production.cutting.enums;

public enum MaterialType {
    ARAMIDA,
    TENSYLON
}
