package cars.carbon.printService.production.cutting.service;

import cars.carbon.printService.enums.PlateEventType;
import cars.carbon.printService.model.plate.PlateEvent;
import cars.carbon.printService.model.plate.Plates;
import cars.carbon.printService.production.cutting.model.CuttingLot;
import cars.carbon.printService.production.cutting.model.CuttingProduction;
import cars.carbon.printService.production.cutting.repository.CuttingProductionRepository;
import cars.carbon.printService.repository.PlateEventRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class CuttingProductionService {

    private final CuttingProductionRepository cuttingRepository;
    private final PlateEventRepository plateEventRepository;

    public CuttingProductionService(
            CuttingProductionRepository repository,
            PlateEventRepository plateEventRepository) {

        this.cuttingRepository = repository;
        this.plateEventRepository = plateEventRepository;
    }

    @Transactional
    public CuttingProduction registerCutting(CuttingProduction cutting) {

        CuttingProduction saved = cuttingRepository.save(cutting);

        if (saved.getLots() != null) {

            for (CuttingLot lot : saved.getLots()) {

                if (lot.getPlates() != null) {

                    for (Plates plate : lot.getPlates()) {

                        PlateEvent event = new PlateEvent();
                        event.setPlate(plate);
                        event.setEventType(PlateEventType.USO_CORTE);
                        event.setEventDate(LocalDateTime.now());
                        event.setReferenceId(saved.getId());
                        event.setDescription("Placa utilizada no corte");

                        plateEventRepository.save(event);
                    }

                }

            }

        }

        return saved;
    }

    public CuttingProduction findById(Long id) {
        return cuttingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Corte não encontrado"));
    }

    public void delete(Long id) {
        cuttingRepository.deleteById(id);
    }

    public CuttingProduction create(CuttingProduction production) {
        production.setProductionDate(LocalDateTime.now());
        return cuttingRepository.save(production);
    }
}
