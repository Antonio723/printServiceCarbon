package cars.carbon.printService.production.cutting.enums;

public enum LotType {
    INTERNAL,
    EXTERNAL
}
