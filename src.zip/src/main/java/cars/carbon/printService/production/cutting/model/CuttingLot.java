package cars.carbon.printService.production.cutting.model;

import cars.carbon.printService.model.plate.Plates;
import cars.carbon.printService.production.cutting.enums.SupplierType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
public class CuttingLot {

    @Id
    @GeneratedValue
    private Long id;

    private String lotNumber;

    private Double length;

    @Enumerated(EnumType.STRING)
    private SupplierType supplier;

    @ManyToOne
    private CuttingProduction cuttingProduction;

    @ManyToMany
    private List<Plates> plates;
}
