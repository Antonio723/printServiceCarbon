package cars.carbon.printService.production.cutting.model;

import cars.carbon.printService.production.cutting.enums.LotType;
import jakarta.persistence.*;

@Entity
public class CuttingMaterialUsage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String lot;

    private Double lengthUsed;

    private String supplier;

    @Enumerated(EnumType.STRING)
    private LotType lotType;

    @ManyToOne
    @JoinColumn(name = "production_id")
    private CuttingProduction production;
}