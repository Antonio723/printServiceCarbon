package cars.carbon.printService.enums;

public enum PackageStatus {
    PREPARANDO,
    PREPARADO,
    PROCESSADO,
    FALHOU
}
