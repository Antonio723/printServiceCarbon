package cars.carbon.printService.enums;

public enum PackageStatus {
    PREPARANDO,
    EM_CICLO,
    APROVADO,
    FALHOU
}
