package cars.carbon.printService.enums;

public enum PlateEventType {
    ATUALIZACAO,
    AUTOCLAVE,
    CONSUMO,
    CANCELAMENTO_DE_CONSUMO
}
