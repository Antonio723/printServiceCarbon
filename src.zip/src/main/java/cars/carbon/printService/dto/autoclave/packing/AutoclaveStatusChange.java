package cars.carbon.printService.dto.autoclave.packing;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutoclaveStatusChange {
    private String newStatus;
}
