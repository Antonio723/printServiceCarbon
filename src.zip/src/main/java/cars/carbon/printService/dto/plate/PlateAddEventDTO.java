package cars.carbon.printService.dto.plate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlateAddEventDTO {
    public long plateId;
}
