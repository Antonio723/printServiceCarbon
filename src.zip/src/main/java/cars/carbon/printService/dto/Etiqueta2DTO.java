package cars.carbon.printService.dto;

public class Etiqueta2DTO {
    private String material;
    private String process;
    private String plateBatch;
    private String plastic;
    private String plasticBatch;
    private String cloth;
    private String clothBatch;
    private String required;
    private String observation;

    public String getClothBatch() {
        return clothBatch;
    }

    public void setClothBatch(String clothBatch) {
        this.clothBatch = clothBatch;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }

    public String getPlateBatch() {
        return plateBatch;
    }

    public void setPlateBatch(String plateBatch) {
        this.plateBatch = plateBatch;
    }

    public String getPlastic() {
        return plastic;
    }

    public void setPlastic(String plastic) {
        this.plastic = plastic;
    }

    public String getPlasticBatch() {
        return plasticBatch;
    }

    public void setPlasticBatch(String plasticBatch) {
        this.plasticBatch = plasticBatch;
    }

    public String getCloth() {
        return cloth;
    }

    public void setCloth(String cloth) {
        this.cloth = cloth;
    }

    public String getRequired() {
        return required;
    }

    public void setRequired(String required) {
        this.required = required;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }
}
